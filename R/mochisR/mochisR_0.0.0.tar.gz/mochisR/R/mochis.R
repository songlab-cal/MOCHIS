#' Flexible Non-Parametric One- and Two-Sample Tests (Native R version)
#'
#' Given data consisting of either a single sample \eqn{\boldsymbol{x}=(x_1,\ldots,x_k)},
#' or two samples \eqn{\boldsymbol{x}=(x_1,\ldots,x_k)} and \eqn{\boldsymbol{y}=(y_1,\ldots,y_n)},
#' this function uses summary statistics computed on weighted linear combinations of powers of
#' the spacing statistics \eqn{S_k} (former) or \eqn{S_{n,k}} (latter).
#'
#' More precisely, this function does the following:
#'
#' For a single sample \eqn{x}, the function tests for uniformity of its entries. When \eqn{p=2}
#' and a particular choice of \eqn{\boldsymbol{w}} is specified, we recover Greenwood's test.
#'
#' For two samples, the function tests the null of \eqn{\boldsymbol{x}} and \eqn{\boldsymbol{y}}
#' being drawn from the same distribution (i.e., stochastic equality), against flexible alternatives
#' that correspond to specific choices of the test statistic parameters, \eqn{\boldsymbol{w}} (weight vector)
#' and \eqn{p} (power). These parameters not only determine the test statistic
#' \eqn{||S_k||_{p,\boldsymbol{w}}^p=\sum_{j=1}^k w_iS_{k}[j]^p} (analogously defined for
#' \eqn{||S_{n,k}||_{p,\boldsymbol{w}}^p}), but also encode alternative hypotheses
#' ranging from different populational means (i.e., \eqn{\mu_x \neq \mu_y}), different
#' populational spreads (i.e., \eqn{\sigma^2_x \neq \sigma^2_y}), etc.
#'
#' Additional tuning parameters include (1) choice of p-value computation (one- or two-sided);
#' (2) approximation method (moment-based such as Bernstein, Chebyshev or Jacobi, or resampling-based);
#' (3) number of moments accompanying the approximation chosen if using moment-based approximation
#' (recommended 200, typically at least 100); and (4) in case of two samples,
#' whether the user prefers to use exact discrete moments (more accurate but slower) or to use
#' continuous approximations of the discrete moments (less accurate but faster).
#'
#' (4/21/22) Currently, only resampling and Gaussian asymptotics are supported. Both are efficient and well-calibrated.
#'
#' (4/14/22) Currently, for \eqn{n\geqslant 100} and \eqn{k\geqslant 50} such that \eqn{\frac{k}{n}\geqslant 0.001}, function
#' automatically uses Gaussian approximation to the null.
#'
#' Dependencies: functions in `auxiliary.R`
#' @param x First sample
#' @param y Second sample
#' @param p Exponent value in defining test statistic (must be integer)
#' @param wList Vector of weights. It should have length equal to \eqn{x} when \eqn{y} is `NULL`,
#' and one more than the length of \eqn{x} when \eqn{y} is not `NULL`
#' @param alternative How p-value should be computed; i.e., a character specifying the alternative hypothesis,
#' must be one of "`two.sided`", "`greater`" or "`less`"
#' @param approx Which approximation method to use (choose `resample`, `bernstein`, `chebyshev`, `jacobi`)
#' @param type If using resampling approximation, either an unbiased estimate of (`'unbiased'`, default),
#' or valid, but biased estimate of, (`'valid'`) p-value (see Hemerik and Goeman, 2018), or both (`'both'`). Default is `'unbiased'`.
#' @param n_mom The number of moments to accompany the approximation (recommended 200, if not at least 100)
#' @param resamp_number Number of \eqn{k}-compositions of \eqn{n} or simplex vectors in \eqn{[0,1]^k}  to draw
#' @param force_discrete In the two-sample case, whether to use discrete moments even if \eqn{n} is large enough (default is `FALSE`)
#' @export
#' @examples
#'
#' # One-sample examples
#' #mochisR(x = abs(rnorm(10)), p = 2, wList = rep(1,10), alternative = "two.sided", approx = "chebyshev", n_mom = 200)
#' #mochisR(x = abs(rnorm(10)), p = 2, wList = rep(1,10), alternative = "two.sided", approx = "bernstein", n_mom = 200)
#' #mochisR(x = abs(rnorm(10)), p = 2, wList = rep(1,10), alternative = "two.sided", approx = "jacobi", n_mom = 100)
#' mochisR(x = abs(rnorm(10)), p = 2, wList = rep(1,10), alternative = "two.sided", approx = "resample")
#'
#' # Two-sample examples
#' #mochisR(x = abs(rnorm(10)), y = abs(rnorm(100)), p = 2, wList = rep(1,11), alternative = "two.sided", approx = "chebyshev", n_mom = 200)
#' #mochisR(x = abs(rnorm(10)), y = abs(rnorm(100)), p = 2, wList = rep(1,11), alternative = "two.sided", approx = "bernstein", n_mom = 200)
#' #mochisR(x = abs(rnorm(10)), y = abs(rnorm(100)), p = 2, wList = rep(1,11), alternative = "two.sided", approx = "jacobi", n_mom = 200)
#' mochisR(x = abs(rnorm(30)), y = abs(rnorm(100)), p = 2, wList = rep(1,31), alternative = "two.sided", approx = "resample", resamp_number = 5000)
mochisR <- function(x, y,
                    p,
                    wList,
                    alternative,
                    approx,
                    type,
                    n_mom,
                    resamp_number,
                    force_discrete = FALSE) {
  # 1. Get number of bins
  if (!is.null(y)) {
    k <- length(x) + 1
  } else {
    k <- length(x)
  }

  # 2. Normalise weights
  message(date(), ": Normalizing weight vector...")
  wList <- wList / max(wList)

  # 3. Compute test statistic t and return its p-value
  # 3.1. Case 1: y is not NULL
  if (!is.null(y)) {
    # construct ordering of x_i's
    x_ordered <- x[order(x)]
    x_ordered <- c(-Inf, x_ordered, Inf)
    n <- length(y) # get sample size / number of balls

    # construct Snk
    Snk <- c()
    for (i in 1:k) {
      # count number of y_j's between x_i and x_{i+1}
      Snk <- c(Snk, sum(y >= x_ordered[i] &  y < x_ordered[i+1]))
    }

    # construct t
    if (approx == "resample" & !(n >= 100 & k >= 50 & k/n >= 1e-3 & (p == 1 | p == 2))) {
      t <- sum(((Snk+1)/(n+k))^p * wList)
      message(date(), ": Adjusting n and k for resampling")
    } else {
      t <- sum((Snk/n)^p * wList)
    }
    message(date(), ": The test statistic for the data is ", round(t,digits=4))

    # decide on an approximation:
    # first, decide whether to use large n, large k asymptotics
    if (n >= 100 & k >= 50 & k/n >= 1e-3 & (p == 1 | p == 2)) {
      message(
        date(),
        ": Sample sizes, n and k, large enough such that k/n > 0; p = 1 or p = 2. Applying Gaussian asymptotics...")
      # compute analytical mean and variance
      if (p == 1) {
        # p = 1
        first_moment <- sum(wList) / k
        second_moment <- ((k/n+1)/(k^2*(k+1))) *
          sum(wList *((k*diag(k) - outer(rep(1,k),rep(1,k))) %*% wList))
      } else {
        # p = 2
        first_moment <- ((2+k/n-1/n) / ((k+1)*k)) * sum(wList)
        sum_of_wj2s <- sum(wList^2)
        coeff_sum_of_wj2s <- (k-1) * (k/n+1) * (2+k/n-1/n) * (12-6/n+k*(k/n+10-5/n)) / (k^2*(1+k)^2*(2+k)*(3+k))
        offdiag_sum <- sum(outer(wList, wList)) - sum(wList^2)
        coeff_offdiag_sum <- (k/n+1) * (6/n^2+k*(3+k*(k-2))/n^2-24/n+8*(k-1)*k/n+8*(3+2*k)) / (k^2*(1+k)^2*(2+k)*(3+k))
        second_moment <- sum_of_wj2s * coeff_sum_of_wj2s - offdiag_sum * coeff_offdiag_sum
      }

      z_score <- (t - first_moment) / sqrt(second_moment)

      if (alternative == "two.sided") {
        return(2*min(pnorm(z_score), pnorm(-z_score)))
      } else if (alternative == "greater") {
        return(pnorm(-z_score))
      } else {
        return(pnorm(z_score))
      }

    } else if (approx == "resample") {
      message(date(),
              ": Using resampling approach, with resampling number ", resamp_number,", to approximate p-value...")
      return(getCompositionPValue(t = t, n = n + k, k = k, p = p,
                                  wList = wList,
                                  alternative = alternative,
                                  type = type,
                                  resamp_number = resamp_number))

    } else if (n >= 100 & !force_discrete) {
      message(date(), ": Sample size, n, is large enough, using Sk distribution...")

      # compute continuous moments
      message(date(), ": Computing continuous moments...")
      moment_seq <- continuousMoments(m = n_mom, p = p, k = k, wList = wList)

      # compute and return p-value
      if (approx == "bernstein") {
        return(getBernsteinPValue(t = t,
                                  n_mom = n_mom,
                                  p = p, k = k,
                                  moment_seq = moment_seq,
                                  alternative = alternative,
                                  wList = wList))
      } else {
        return(getMomentPValue(t = t,
                               n_mom = n_mom,
                               moment_seq = moment_seq,
                               method = approx,
                               alternative = alternative))
      }
    } else {
      message(date(), ": Using Snk distribution...")

      # compute discrete moments
      message(date(), ": Computing discrete moments...")
      moment_seq <- discreteMoments(m = n_mom, n = n, k = k, p = p, wList = wList)

      # compute and return p-value
      if (approx == "bernstein") {
        return(getBernsteinPValue(t = t,
                                  n_mom = n_mom,
                                  p = p, k = k,
                                  moment_seq = moment_seq,
                                  alternative = alternative,
                                  wList = wList))
      } else {
        return(getMomentPValue(t = t,
                               n_mom = n_mom,
                               moment_seq = moment_seq,
                               method = approx,
                               alternative = alternative))
      }
    }

  } else {
    # 3.2. Case 2: y is NULL => use continuous moments
    # check all entries of observations are non-negative
    assertthat::assert_that(!any(x < 0),
                            msg = "Observations should be non-negative")
    # construct Sk
    Sk <- x / sum(x)

    # construct t
    t <- sum(Sk^p * wList)
    message(date(), ": The test statistic for the data is ", t)

    # decide on approximation
    if (approx == "resample") {
      message(date(),
              ": Using resampling approach on continuous simplex, with resampling number ",
              resamp_number,", to approximate p-value...")
      resampled_ts <- as.vector((simplex.sample(n=k,N=resamp_number)$samples)^p %*% wList)

      # compute unbiased and valid upper and lower cdfs
      cdf_at_t <- mean(resampled_ts < t)
      cdf_at_t_upp_tail <- 1 - mean(c(resampled_ts,t) >= t)
      cdf_at_t_low_tail <- mean(c(resampled_ts,t) <= t)

      if (alternative == "two.sided") {
        message(date(), ": Computing two-sided p-value")
        if (type == "unbiased") {
          return(2*min(cdf_at_t, 1 - cdf_at_t))
        } else if (type == "valid") {
          return(2*min(cdf_at_t_low_tail, 1 - cdf_at_t_upp_tail))
        } else {
          unbiased <- 2*min(cdf_at_t, 1 - cdf_at_t)
          valid <- 2*min(cdf_at_t_low_tail, 1 - cdf_at_t_upp_tail)
          to_return <- c(unbiased,valid)
          names(to_return) <- c("unbiased","valid")
          return(to_return)
        }
      } else if (alternative == "greater") {
        message(date(), ": Computing one-sided p-value with alternative set to `greater`")
        if (type == "unbiased") {
          return(1 - cdf_at_t)
        } else if (type == "valid") {
          return(1 - cdf_at_t_upp_tail)
        } else {
          unbiased <- 1 - cdf_at_t
          valid <- 1 - cdf_at_t_upp_tail
          to_return <- c(unbiased,valid)
          names(to_return) <- c("unbiased","valid")
          return(to_return)
        }
      } else {
        message(date(), ": Computing one-sided p-value with alternative set to `less`")
        if (type == "unbiased") {
          return(cdf_at_t)
        } else if (type == "valid") {
          return(cdf_at_t_low_tail)
        } else {
          unbiased <- cdf_at_t
          valid <- cdf_at_t_low_tail
          to_return <- c(unbiased,valid)
          names(to_return) <- c("unbiased","valid")
          return(to_return)
        }
      }
    } else {
      # compute moments
      moment_seq <- continuousMoments(m = n_mom, p = p, k = k, wList = wList)

      # return p-value according to choice of numerical approximation
      if (approx == "bernstein") {
        return(getBernsteinPValue(t = t,
                                  n_mom = n_mom,
                                  p = p, k = k,
                                  moment_seq = moment_seq,
                                  alternative = alternative,
                                  wList = wList))
      } else {
        return(getMomentPValue(t = t,
                               n_mom = n_mom,
                               moment_seq = moment_seq,
                               method = approx,
                               alternative = alternative))
      }
    }
  }
}

#' MOCHIS
#'
#' Given data consisting of either a single sample \eqn{\boldsymbol{x}=(x_1,\ldots,x_k)},
#' or two samples \eqn{\boldsymbol{x}=(x_1,\ldots,x_k)} and \eqn{\boldsymbol{y}=(y_1,\ldots,y_n)},
#' this function uses summary statistics computed on weighted linear combinations of powers of
#' the spacing statistics \eqn{S_k} (former) or \eqn{S_{n,k}} (latter).
#'
#' For a single sample \eqn{x}, the function tests for uniformity of its entries. When \eqn{p=2}
#' and \eqn{\boldsymbol{w}=(1,\ldots,1)}, the test is just Greenwood's test.
#'
#' For two samples, the function tests the null of \eqn{x} and \eqn{y} being drawn from the
#' same distribution (i.e., stochastic equality), against flexible alternatives that correspond
#' to specific choices of the test statistic parameters, \eqn{\boldsymbol{w}} (weight vector) and
#' \eqn{p} (power). These parameters not only determine the test statistic
#' \eqn{||S_k||_{p,\boldsymbol{w}}^p=\sum_{j=1}^k w_iS_{k}[j]^p} (analogously defined for
#' \eqn{||S_{n,k}||_{p,\boldsymbol{w}}^p}), but also encode alternative hypotheses
#' ranging from different populational means (i.e., \eqn{\mu_x \neq \mu_y}), different
#' populational spreads (i.e., \eqn{\sigma^2_x \neq \sigma^2_y}), etc.
#'
#' Additional tuning parameters include (1) choice of Python or R backend  (Python is much faster but requires
#' Python installation); (2) choice of p-value computation (one- or two-sided); (3) approximation method
#' (moment-based like Bernstein, Chebyshev, Jacobi, or resampling-based); (4) number of moments accompanying
#' the approximation chosen if using moment-based approximation (recommended 200, typically at least 100);
#' and (5) in case of two samples, whether the user prefers to use exact discrete moments (more accurate but slower)
#' or to use continuous approximations of the discrete moments (less accurate but faster).
#'
#' (5/30/22) Included an implementation that adds small bias to the p-value computation. This
#' provably controls the Type I Error, especially at very small significance thresholds, which
#' occur commonly in multiple testing applications.
#'
#' (4/21/22) Currently, **only resampling and Gaussian asymptotics are supported**. Both are efficient and well-calibrated.
#'
#' (4/14/22) Currently, for \eqn{n\geqslant 100} and \eqn{k\geqslant 50} such that \eqn{\frac{k}{n}\geqslant 0.001}, function
#' automatically uses Gaussian approximation to the null.
#'
#' Dependencies: mochisR
#' @param x First sample
#' @param y Second sample (default is NULL)
#' @param p Exponent value in defining test statistic (must be integer for continuous moments)
#' @param wList Vector of weights. It should always have length one more than the length of \eqn{x}
#' @param alternative How p-value should be computed; i.e., a character specifying the alternative hypothesis,
#' must be one of `"two.sided"` (default), `"greater"` or `"less"`
#' @param approx Which approximation method to use (choose `"resample"`, `"bernstein"`, `"chebyshev"`, `"jacobi"`)
#' @param type If using resampling approximation, either an unbiased estimate of (`"unbiased"`, default),
#' or valid, but biased estimate of (`"valid"`), p-value (see Hemerik and Goeman, 2018), or both (`"both"`). Default is `"unbiased"`.
#' @param n_mom The number of moments to accompany the approximation (recommended 200, if not at least 100)
#' @param resamp_number Number of compositions of \eqn{n} to draw (default is 5000)
#' @param force_discrete In the two-sample case, whether to use discrete moments even if \eqn{n} is large enough (default is `FALSE`)
#' @param python_backend To use Python or R backend (default is `FALSE`), with `TRUE` indicating that a call to Pythonic functions should be executed
#' @param use_base_r Decide whether or not to use native R functions for edge cases like Mann-Whitney (default is `TRUE`)
#' @export
#' @examples
#'
#' # One-sample examples
#' mochis.test(x = abs(rnorm(10)), p = 2, wList = rep(1,10), alternative = "two.sided", approx = "resample")
#'
#' # Two-sample examples
#' mochis.test(x = abs(rnorm(10)),
#' y = abs(rnorm(100)), p = 2,
#' wList = rep(1,11),
#' alternative = "two.sided",
#' approx = "resample")
#'
#' mochis.test(x = abs(rnorm(10)),
#' y = abs(rnorm(100)), p = 1,
#' wList = 10:0,
#' alternative = "two.sided",
#' approx = "resample")
#'
#' mochis.test(x = abs(rnorm(10)),
#' y = abs(rnorm(100)), p = 1,
#' wList = 10:0,
#' alternative = "two.sided",
#' approx = "resample",
#' use_base_r = FALSE)
mochis.test <- function(x, y = NULL,
                        p,
                        wList,
                        alternative = "two.sided",
                        approx = "resample",
                        type = "unbiased",
                        n_mom,
                        resamp_number = 5000,
                        force_discrete = FALSE,
                        python_backend = FALSE,
                        use_base_r = TRUE) {
  # assert that length(x) and length(y) are compatible
  if (!is.null(y)) {
    assertthat::assert_that(length(x) <= length(y),
                            msg = "Length of x is larger than length of y, swap the samples so that x is shorter than y.")
  }

  # assert that p is a positive integer
  assertthat::assert_that(p > 0 & (abs(p - round(p)) < .Machine$double.eps^0.5),
                          msg = "Currently only supporting positive integer values of p. Check that p is a positive integer.")

  # assert that wList is compatible with x and y
  if (is.null(y)) {
    assertthat::assert_that(length(x) == length(wList),
                            msg = "Length of wList must be same as length of the sample, x.")
  } else {
    assertthat::assert_that(length(x) + 1 == length(wList),
                            msg = "Length of wList must be one more than length of smaller sample, x.")
  }

  # assert that alternative is well-defined
  assertthat::assert_that((alternative == "two.sided" | alternative == "greater" | alternative == "less"),
                          msg = "Please specify a valid alternative (`two.sided`, `greater`, or `less`)")

  # assert that approx is well-defined
  #assertthat::assert_that((approx == "resample" | approx == "bernstein" | approx == "chebyshev" | approx == "jacobi"),
  #                        msg = "Please specify a valid approximation (`resample`, `bernstein`, `chebyshev` or `jacobi`)")
  assertthat::assert_that((approx == "resample"),
                          msg = "This version does not currently support the use of moment-based approximation. Please use `resample` instead.")

  # assert that type is well-defined
  assertthat::assert_that((type == "unbiased" | type == "valid" | type == "both"),
                          msg = "Please specify a valid type (`unbiased`, `valid`, or `both`)")

  # edge case
  if (identical(wList,(length(x):0)) & p == 1 & use_base_r) {
    message(date(), ": Settings correspond to Mann-Whitney, using base R...")
    return(wilcox.test(x, y, alternative = alternative, correct=FALSE)$p.value)
  } else {
    # all other cases
    if (python_backend) {
      #message(date(), ": Using Python3 back-end to compute p-value...")
      #return(mochisPy(x, y, p, wList, alternative, approx, n_mom, force_discrete))
      message(date(), ": Python calling is currently not supported. Please set python_backend to FALSE.")
      return(-99)
    } else {
      message(date(), ": Using native R to compute p-value...")
      return(mochisR(x, y, p, wList, alternative, approx, type, n_mom, resamp_number, force_discrete))
    }
  }
}
