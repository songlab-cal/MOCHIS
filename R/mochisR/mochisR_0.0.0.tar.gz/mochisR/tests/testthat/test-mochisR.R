#' This script performs unit  tests on all functions.
#'

## Set seed for reproducibility
set.seed(2022)

## Test uniformity and positivity of exact p-values under the null (p=1)
test_that("Exact p-values are positive and uniformly distributed under null for p=1", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 1
  wList <- runif(10, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:100) {
    x <- rnorm(9); y <- rnorm(15)
    x_ordered <- x[order(x)]
    x_ordered <- c(-Inf, x_ordered, Inf)
    k <- length(x)+1 # get number of bins
    n <- length(y) # get sample size / number of balls
    # construct Snk
    Snk <- c()
    for (i in 1:k) {
      # count number of y_j's between x_i and x_{i+1}
      Snk <- c(Snk, sum(y >= x_ordered[i] &  y < x_ordered[i+1]))
    }
    # construct t
    t <- sum(((Snk+1)/(n+k))^p * wList)

    # Compute p-value (check that it is uniform)
    p.val <- getCompositionPValue(t=t,n=n+k,k=k,p=p,
                                  wList=wList,alternative="two.sided")
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(min(p.val.vec) > 0,
                        label = "Minimum p-value is positive")
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.1,
                        label = "Distribution of p-values is uniform")
})

## Test uniformity and positivity of exact p-values under the null (p=2)
test_that("Exact p-values are positive and uniformly distributed under null for p=2", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 2
  wList <- runif(10, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:100) {
    x <- abs(rnorm(9)); y <- abs(rnorm(15))
    x_ordered <- x[order(x)]
    x_ordered <- c(-Inf, x_ordered, Inf)
    k <- length(x)+1 # get number of bins
    n <- length(y) # get sample size / number of balls
    # construct Snk
    Snk <- c()
    for (i in 1:k) {
      # count number of y_j's between x_i and x_{i+1}
      Snk <- c(Snk, sum(y >= x_ordered[i] &  y < x_ordered[i+1]))
    }
    # construct t
    t <- sum(((Snk+1)/(n+k))^p * wList)

    # Compute p-value (check that it is uniform)
    p.val <- getCompositionPValue(t=t,n=n+k,k=k,p=p,
                                  wList=wList,alternative="two.sided")
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(min(p.val.vec) > 0,
                        label = "Minimum p-value is positive")
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.01,
                        label = "Distribution of p-values is uniform")
})

## Test uniformity and positivity of resampling p-values under the null (p=1)
test_that("Resampling p-values are positive and uniformly distributed under null for p=1", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 1
  wList <- runif(30, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:1000) {
    x <- abs(rnorm(29)); y <- abs(rnorm(40))
    x_ordered <- x[order(x)]
    x_ordered <- c(-Inf, x_ordered, Inf)
    k <- length(x)+1 # get number of bins
    n <- length(y) # get sample size / number of balls
    # construct Snk
    Snk <- c()
    for (i in 1:k) {
      # count number of y_j's between x_i and x_{i+1}
      Snk <- c(Snk, sum(y >= x_ordered[i] &  y < x_ordered[i+1]))
    }
    # construct t
    t <- sum(((Snk+1)/(n+k))^p * wList)

    # Compute p-value (check that it is uniform)
    p.val <- getCompositionPValue(t=t,n=n+k,k=k,p=p,
                                  wList=wList,alternative="two.sided",
                                  type="valid",
                                  resamp_number = 5000)
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(min(p.val.vec) > 0,
                        label = "Minimum p-value is positive")
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.01,
                        label = "Distribution of p-values is uniform")
})

## Test uniformity and positivity of resampling p-values under the null (p=2)
test_that("Resampling p-values are positive and uniformly distributed under null for p=2", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 2
  wList <- runif(30, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:1000) {
    x <- abs(rnorm(29)); y <- abs(rnorm(40))
    x_ordered <- x[order(x)]
    x_ordered <- c(-Inf, x_ordered, Inf)
    k <- length(x)+1 # get number of bins
    n <- length(y) # get sample size / number of balls
    # construct Snk
    Snk <- c()
    for (i in 1:k) {
      # count number of y_j's between x_i and x_{i+1}
      Snk <- c(Snk, sum(y >= x_ordered[i] &  y < x_ordered[i+1]))
    }
    # construct t
    t <- sum(((Snk+1)/(n+k))^p * wList)

    # Compute p-value (check that it is uniform)
    p.val <- getCompositionPValue(t=t,n=n+k,k=k,p=p,
                                  wList=wList,alternative="two.sided",
                                  type="valid",
                                  resamp_number = 5000)
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(min(p.val.vec) > 0,
                        label = "Minimum p-value is positive")
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.01,
                        label = "Distribution of p-values is uniform")
})

## Test uniformity of Gaussian p-values under the null (p=1)
test_that("Gaussian p-values are uniformly distributed under null for p=1", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 1
  wList <- runif(51, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:1000) {
    x <- rnorm(50); y <- rnorm(100)
    # Compute p-value (check that it is uniform)
    p.val <- mochisR(x=x,y=y,
                     p=p,wList=wList,
                     approx="resample",
                     alternative="two.sided",
                     force_discrete = FALSE)
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.01,
                        label = "Distribution of p-values is uniform")
})

## Test uniformity of Gaussian p-values under the null (p=2)
test_that("Gaussian p-values are uniformly distributed under null for p=2", {
  # Skip if run on Linux
  skip_on_os(c("linux", "windows", "solaris"))

  # Test on synthetic data
  p <- 2
  wList <- runif(51, min=1, max=10)
  p.val.vec <- c()
  for (i in 1L:1000) {
    x <- rnorm(50); y <- rnorm(100)
    # Compute p-value (check that it is uniform)
    p.val <- mochisR(x=x,y=y,
                     p=p,wList=wList,
                     approx="resample",
                     alternative="two.sided",
                     force_discrete = FALSE)
    p.val.vec <- c(p.val.vec, p.val)
  }
  testthat::expect_true(abs(mean(p.val.vec)-0.5) < 0.1 & abs(var(p.val.vec)-1/12) < 0.01,
                        label = "Distribution of p-values is uniform")
})
